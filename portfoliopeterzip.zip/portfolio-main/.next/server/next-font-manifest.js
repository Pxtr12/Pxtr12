self.__NEXT_FONT_MANIFEST={
  "pages": {
    "/": [
      "static/media/28661e5f0c90e6a5-s.p.woff2",
      "static/media/e5f193da326e76b4-s.p.woff2",
      "static/media/d9404ee23c745276-s.p.woff2"
    ]
  },
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": true
}